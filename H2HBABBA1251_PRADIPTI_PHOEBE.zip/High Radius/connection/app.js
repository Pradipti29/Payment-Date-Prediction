const express = require("express")

const app=express();

const mongoose = require('mongoose');
// const mongodb=require('mongodb');
// const MongoClient = mongodb.MongoClient;
let multer = require('multer');
let cors = require('cors')
// const bodyParser= require('body-parser');
const path = require('path')
// require('dotenv/config');
//*Seting Template Engines
app.set("view engine", "ejs");
app.set("views", "views");
app.use(cors());
//* stting up public folder
app.use(express.static(path.join(__dirname, "public")));


//Importing routes
let locationRoute=require('./routes/router');


// ?multer specification for ther server
const fileStorage = multer.diskStorage({

    destination:(req,file,cb)=>{
      cb(null,'pics');
    },
    filename:(req,file,cb)=>{
      cb(null,Date.now()+'.jpg');
    },
  })
  
// *now using the fileStorage object here and the "name " attr of the form
  // app.use(multer({dest:'excels'}).single('fileInput'))
  app.use(multer({storage:fileStorage}).single('image'))

// !404 routing
// app.use((req,res,next)=>{
//     res.status(404).sendFile(path.join(__dirname,'views','404.html'))
//     // console.log('404 page not found!');
// })

app.use('/',locationRoute);



mongoose.connect('mongodb+srv://testboy:rhyno54@cluster0.kn2jf.mongodb.net/locate_me?retryWrites=true&w=majority',(err,res)=>{
    if(!err){    console.log('Conneted !');}
    else{
        console.log(err);
    }

});




//LISTMIOG
app.listen(3000);