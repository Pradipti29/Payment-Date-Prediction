const mongoose = require('mongoose');

const locationSchem= mongoose.Schema({
    Image:{
        type:Image,
        required:true
    },
    lat:{
        type:String,
        required:true,
    },
    lon:{
        type:String,
        required:true,
    },
    date:{
        type:Date,
        default:Date.now
    }
})

module.exports=mongoose.model('locations',locationSchem)