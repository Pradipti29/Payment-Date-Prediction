const express = require('express');
const router = express.Router();
const locationService = require('../services/locationService');

router.get('/',locationService.getForm);
router.post('/sendPic',locationService.sendPic);


module.exports = router;