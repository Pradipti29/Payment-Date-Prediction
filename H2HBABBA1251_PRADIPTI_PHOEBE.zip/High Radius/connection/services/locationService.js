const data= require('../data.json')

const locationService={

    getForm:async (req,res)=>{
        console.log('Home');
        // res.send('Hel')
        // res.render('../views/index');
        res.json(data );
    },
    sendPic:async(req,res)=>{
        console.log('pic posted!');
        res.send('Pic Snet');
    }



}

module.exports = locationService;
