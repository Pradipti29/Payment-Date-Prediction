function AddData() {
    var e = document.getElementById("cbox").innerHTML;
    var x = document.getElementById("nm1").value;
    var y = document.getElementById("dt1").value;
    var a = document.getElementById("no1").value;
    var b = document.getElementById("note1").value;
    var c = document.getElementById("inm1").value;
    var d = document.getElementById("inma1").value;
    var f = document.getElementById("ppd").value;
    var letters = '/^[a-zA-Z]+$/';
    if ((parseInt(x) != (x)) && (y == parseInt(y)) &&(a == parseInt(a))&&(b == parseInt(b))&&(c == parseInt(c))&&(d == parseInt(d))&&(e==parseInt(e))&&(f==parseInt(f))) {
        alert("Wrong Value Entered");
    } else {
        var rows = "";
        var cbox =  document.getElementById("cbox").innerHTML;
        var nm1 =  document.getElementById("nm1").value;
        var dt1 =  document.getElementById("dt1").value;
        var no1 =  document.getElementById("no1").value;
        var note1 =  document.getElementById("note1").value;
        var ppd =  document.getElementById("ppd").value;
        var inm1 = document.getElementById("inm1").value;
        var inma1 = document.getElementById("inma1").value;

        rows += "<td>" + cbox + "</td> <td>" + nm1 + "</td><td>" + no1 + "</td><td>" + inm1 + "</td><td>" + inma1 + "</td><td>"+dt1+ "</td><td>" + ppd +"</id><td>" + note1 +"</id>"  ;
        var tbody = document.querySelector("#list tbody");
        var tr = document.createElement("tr");

        tr.innerHTML = rows;
        tbody.appendChild(tr)

        //
    }
}

function ResetForm() {
    document.getElementById("person").reset();
}


   
