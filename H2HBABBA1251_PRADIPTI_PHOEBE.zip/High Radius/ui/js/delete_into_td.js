function Delete(){ 
    var par = $(this).parent().parent(); 
     par.remove(); };


let delBox=  document.getElementById('chBox');


delBox.addEventListener("click",(data)=>{
    console.log('Info'+ data);
})

