function Save(){
     var par = $(this).parent().parent(); 
     var tdName = par.children("td:nth-child(1)"); 
     var tdPhone = par.children("td:nth-child(2)"); 
     var tdEmail = par.children("td:nth-child(3)");
      var tdButtons = par.children("td:nth-child(4)");
       tdName.html(tdName.children("input[type=text]").val());
        tdPhone.html(tdPhone.children("input[type=text]").val());
         tdEmail.html(tdEmail.children("input[type=text]").val()); 
         tdButtons.html("<img src='images/delete.png' class='btnDelete'/><img src='images/pencil.png' class='btnEdit'/>");
          $(".btnEdit").bind("click", Edit);
           $(".btnDelete").bind("click", Delete);

}